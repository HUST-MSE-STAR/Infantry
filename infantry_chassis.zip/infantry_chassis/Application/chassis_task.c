#include "chassis_task.h"


chassis_move_t chassis_move;

void chassis_init(chassis_move_t *chassis_move_init)
{
	static fp32 chassis_x_order_filter[1] = {CHASSIS_ACCEL_X_NUM};
	static fp32 chassis_y_order_filter[1] = {CHASSIS_ACCEL_Y_NUM};
	uint8_t i;
	//��ȡ���̿��Ʋ���
	chassis_move_init->chassis_measure = get_chassis_control_measure_point();
	//��ȡ���̵������ָ�룬��ʼ��PID 
	for (i = 0; i < 4; i++)
	{
		chassis_move_init->motor_chassis[i].chassis_motor_measure = get_chassis_motor_measure_point(i);
	}	
  pid_init(&chassis_move_init->motor_speed_pid[0],25,0.05,0,2000,16000);
	pid_init(&chassis_move_init->motor_speed_pid[1],25,0.05,0,2000,16000);
	pid_init(&chassis_move_init->motor_speed_pid[2],25,0.05,0,2000,16000);
	pid_init(&chassis_move_init->motor_speed_pid[3],25,0.05,0,2000,16000);
	
	//��һ���˲�����б����������
	first_order_filter_init(&chassis_move_init->chassis_cmd_slow_set_vx, CHASSIS_CONTROL_TIME, chassis_x_order_filter);
	first_order_filter_init(&chassis_move_init->chassis_cmd_slow_set_vy, CHASSIS_CONTROL_TIME, chassis_y_order_filter);

	chassis_move_init->wheel_perimeter=152*PI;
	chassis_move_init->wheeltrack=430;
	chassis_move_init->wheelbase=360;
	
}

void chassis_task(void const * argument)
{
	uint32_t period = osKernelSysTick();
	//���̳�ʼ��
  chassis_init(&chassis_move);		
	while(1)
	{		
	 chassis_execute(&chassis_move);
	 osDelayUntil(&period, 2);		
	}	
}

void chassis_execute(chassis_move_t *chassis_move_control)//���̿���
{
	fp32 total_current = 0.0f;
	
	mecanum_calculate(chassis_move_control);	//�����ٶȷֽ⵽�ĸ�������

	for (int i = 0; i < 4; i++)		//�������ĸ������ķ�����  ����ԭ����������趨
	{	
		chassis_move_control->motor_chassis[i].give_current=pid_calc(&chassis_move_control->motor_speed_pid[i],chassis_move_control->motor_chassis[i].speed_set,chassis_move_control->motor_chassis[i].chassis_motor_measure->speed_rpm);		
	  total_current += float_abs(chassis_move_control->motor_chassis[i].give_current);
	}	
	chassis_move_control->total_current_limit = chassis_power_control();
	if(total_current > chassis_move_control->total_current_limit)
	{
		fp32 current_scale = chassis_move_control->total_current_limit / total_current;
		chassis_move_control->motor_chassis[0].give_current*=current_scale;
		chassis_move_control->motor_chassis[1].give_current*=current_scale;
		chassis_move_control->motor_chassis[2].give_current*=current_scale;
		chassis_move_control->motor_chassis[3].give_current*=current_scale;
	}
	
	CAN_cmd_chassis(chassis_move_control->motor_chassis[0].give_current, chassis_move_control->motor_chassis[1].give_current, chassis_move_control->motor_chassis[2].give_current, chassis_move_control->motor_chassis[3].give_current);
}
void mecanum_calculate(chassis_move_t *chassis_move_control)//�����ٶȷֽ⵽�ĸ�������	
{
	static float rotate_ratio_fr;//ǰ����ת�� 
	static float rotate_ratio_fl;//ǰ����ת��
	static float rotate_ratio_bl;//������ת��
	static float rotate_ratio_br;//������ת��
	static float wheel_rpm_ratio;

	rotate_ratio_fr = ((chassis_move_control->wheelbase + chassis_move_control->wheeltrack) / 2.0f - chassis_move_control->rotate_x_offset + chassis_move_control->rotate_y_offset) / 57.3f;
	rotate_ratio_fl = ((chassis_move_control->wheelbase + chassis_move_control->wheeltrack) / 2.0f - chassis_move_control->rotate_x_offset - chassis_move_control->rotate_y_offset) / 57.3f;
	rotate_ratio_bl = ((chassis_move_control->wheelbase + chassis_move_control->wheeltrack) / 2.0f + chassis_move_control->rotate_x_offset - chassis_move_control->rotate_y_offset) / 57.3f;
	rotate_ratio_br = ((chassis_move_control->wheelbase + chassis_move_control->wheeltrack) / 2.0f + chassis_move_control->rotate_x_offset + chassis_move_control->rotate_y_offset) / 57.3f;

	wheel_rpm_ratio = 60.0f / (chassis_move_control->wheel_perimeter * MOTOR_DECELE_RATIO);

	float wheel_rpm[4];
	float max = 0;

	wheel_rpm[0] = (chassis_move_control->chassis_measure->chassis_vx - chassis_move_control->chassis_measure->chassis_vy + chassis_move_control->chassis_measure->chassis_wz * rotate_ratio_fr) * wheel_rpm_ratio;
	wheel_rpm[1] = (chassis_move_control->chassis_measure->chassis_vx + chassis_move_control->chassis_measure->chassis_vy + chassis_move_control->chassis_measure->chassis_wz * rotate_ratio_fl) * wheel_rpm_ratio;
	wheel_rpm[2] = (-chassis_move_control->chassis_measure->chassis_vx + chassis_move_control->chassis_measure->chassis_vy + chassis_move_control->chassis_measure->chassis_wz * rotate_ratio_bl) * wheel_rpm_ratio;
	wheel_rpm[3] = (-chassis_move_control->chassis_measure->chassis_vx - chassis_move_control->chassis_measure->chassis_vy + chassis_move_control->chassis_measure->chassis_wz * rotate_ratio_br) * wheel_rpm_ratio;	
	
	//find max item
	for (uint8_t i = 0; i < 4; i++)
	{
		if (float_abs(wheel_rpm[i]) > max)
			max = float_abs(wheel_rpm[i]);
	}	
	
	//equal proportion
	if (max > MAX_WHEEL_RPM)
	{
		float rate = MAX_WHEEL_RPM / max;
		for (uint8_t i = 0; i < 4; i++)
			wheel_rpm[i] *= rate;
	}	

	chassis_move_control->motor_chassis[0].speed_set=wheel_rpm[0];
	chassis_move_control->motor_chassis[1].speed_set=wheel_rpm[1];
	chassis_move_control->motor_chassis[2].speed_set=wheel_rpm[2];
	chassis_move_control->motor_chassis[3].speed_set=wheel_rpm[3];
		
}

