#ifndef __CHASSIS_TASK_H
#define __CHASSIS_TASK_H

#include "main.h"
#include "can_receive.h"
#include "power_control.h"
#include "cmsis_os.h"
#include "control_algorithm.h"

#define CHASSIS_ACCEL_X_NUM 0.1666666667f
#define CHASSIS_ACCEL_Y_NUM 0.3333333333f
#define PI 3.14159265354f
#define MOTOR_DECELE_RATIO (1.0f / 19.0f)
#define MAX_WHEEL_RPM 9000 //9000rpm = 3732mm/s

//����������Ƽ�� 0.002s
#define CHASSIS_CONTROL_TIME 0.002f

typedef struct
{
  motor_measure_t *chassis_motor_measure;  
  fp32 accel;                              
  fp32 speed;                               
  fp32 speed_set;                            
  int16_t give_current;                      
} chassis_motor_t;
typedef struct
{
	chassis_motor_t motor_chassis[4];
	chassis_control_t *chassis_measure;
	pid_type_def motor_speed_pid[4];
	first_order_filter_type_t chassis_cmd_slow_set_vx;  //ʹ��һ�׵�ͨ�˲������趨ֵ
  first_order_filter_type_t chassis_cmd_slow_set_vy;  //ʹ��һ�׵�ͨ�˲������趨ֵ
		
	fp32 total_current_limit;
	
	float wheel_perimeter; /* the perimeter(mm) of wheel */
	float wheeltrack;      /* wheel track distance(mm) */
	float wheelbase;       /* wheelbase distance(mm) */
	float rotate_x_offset; /* rotate offset(mm) relative to the x-axis of the chassis center */
	float rotate_y_offset; /* rotate offset(mm) relative to the y-axis of the chassis center */	
}chassis_move_t;

void chassis_init(chassis_move_t *chassis_move_init);
void chassis_task(void const * argument);
void chassis_execute(chassis_move_t *chassis_move_control);
void mecanum_calculate(chassis_move_t *chassis_move_control);
#endif
