#include "power_control.h"

uint8_t usart6_buf[2][USART_RX_BUF_LENGHT];

frame_header_struct_t referee_receive_header;
ext_power_heat_data_t power_heat_data_t;

static void referee_unpack(uint8_t *referee_buff,int len);
//��ʼ���ṹ��ʹ���6
void init_referee_struct(void)
{
	memset(&referee_receive_header, 0, sizeof(frame_header_struct_t));
	
	memset(&power_heat_data_t, 0, sizeof(ext_power_heat_data_t));
	
	usart6_rx_dma_init(usart6_buf[0], usart6_buf[1], USART_RX_BUF_LENGHT);

}
/**
   *@brief   �������õ�����ϵͳ������
	 *@param   ���յ�����
	 *@retval  ��
	 */
void referee_data_solve(uint8_t *frame)
{
	uint16_t cmd_id = 0;
	uint8_t index = 0;

	memcpy(&referee_receive_header, frame, sizeof(frame_header_struct_t));
	index += sizeof(frame_header_struct_t);

	memcpy(&cmd_id, frame + index, sizeof(uint16_t));
	index += sizeof(uint16_t);	
	
	switch (cmd_id)
	{
		case 0X202:
		{
			 memcpy(&power_heat_data_t, frame + index, sizeof(power_heat_data_t));
		}
		default:
		{
			 break;
		}
				
	}
		
}
/**
   *@brief   �õ����̵Ĺ��ʺͻ���
	 *@param   ���̵Ĺ���
   *@param   ���̵���������
	 *@retval  ��
	 */
void get_chassis_power_and_buffer(fp32 *power, fp32 *buffer)
{
    *power = power_heat_data_t.chassis_power;
    *buffer = power_heat_data_t.chassis_power_buffer;
}
/**
   *@brief   ��������
	 *@note    ������ڴ����жϺ�����
	 *@retval  ��
	 */
void receive_referee(void)
{
	//�ж��Ƿ�����ж�
	if(USART6->SR & UART_FLAG_IDLE)
	{
		__HAL_UART_CLEAR_PEFLAG(&huart6);
		
		static uint16_t this_time_rx_len = 0;
		//�жϽ��н��յĻ�������0�Ż���������1�Ż�����  DMA_SxCR_CT=1
		if ((huart6.hdmarx->Instance->CR & DMA_SxCR_CT) == RESET)
		{
			//ʧЧDMA
			__HAL_DMA_DISABLE(huart6.hdmarx);
			 //��ȡ�������ݳ���,���� = �趨���� - ʣ�೤��
			this_time_rx_len = USART_RX_BUF_LENGHT - __HAL_DMA_GET_COUNTER(huart6.hdmarx);
			//�����趨���ݳ���
			__HAL_DMA_SET_COUNTER(huart6.hdmarx, USART_RX_BUF_LENGHT);
			//�趨������1
			huart6.hdmarx->Instance->CR |= DMA_SxCR_CT;
			//ʹ��DMA
			__HAL_DMA_ENABLE(huart6.hdmarx);
			referee_unpack(usart6_buf[0],this_time_rx_len);
		}
		else
		{
			__HAL_DMA_DISABLE(huart6.hdmarx);
			this_time_rx_len = USART_RX_BUF_LENGHT - __HAL_DMA_GET_COUNTER(huart6.hdmarx);
			__HAL_DMA_SET_COUNTER(huart6.hdmarx, USART_RX_BUF_LENGHT);
			huart6.hdmarx->Instance->CR &= ~(DMA_SxCR_CT);
			__HAL_DMA_ENABLE(huart6.hdmarx);
			referee_unpack(usart6_buf[1],this_time_rx_len);
		}
	}
		
}
/**
   *@brief   ������յ�����
	 *@param   ���յ�����
   *@param   ���ݳ���
	 *@retval  ��
	 */
static void referee_unpack(uint8_t *referee_buff,int len)
{
	static uint8_t unpack_step = 0;
	uint8_t        protocol_packet[REF_PROTOCOL_FRAME_MAX_SIZE];
	static uint16_t index=0;
	
	while ( unpack_step<=STEP_DATA_CRC16 )
	{
		switch(unpack_step)
		{
			case STEP_HEADER_SOF:
			{
				if(referee_buff[0] == 0XA5)
				{
					unpack_step = STEP_LENGTH_LOW;
					referee_receive_header.SOF = referee_buff[index];
					protocol_packet[index] = referee_buff[index];
					index++;
				}			
			}break;
			
			case STEP_LENGTH_LOW:
			{
				referee_receive_header.data_length = referee_buff[index];
				protocol_packet[index] = referee_buff[index];
				unpack_step = STEP_LENGTH_HIGH;
				index++;
			}break;
			
			case STEP_LENGTH_HIGH:
			{
				referee_receive_header.data_length |= (referee_buff[index] << 8);
				protocol_packet[index] = referee_buff[index];
				if(referee_receive_header.data_length < (REF_PROTOCOL_FRAME_MAX_SIZE - REF_HEADER_CRC_CMDID_LEN))
				{
					unpack_step = STEP_FRAME_SEQ;
				}
				index++;
			}break;
			
			case STEP_FRAME_SEQ:
			{
				referee_receive_header.seq = referee_buff[index];
				protocol_packet[index] = referee_buff[index];
				unpack_step = STEP_HEADER_CRC8;
				index++;
			}break;
			
			case STEP_HEADER_CRC8:
			{
				referee_receive_header.CRC8 = referee_buff[index];
				protocol_packet[index] = referee_buff[index];
				if (verify_CRC8_check_sum(protocol_packet, REF_PROTOCOL_HEADER_SIZE) )
				{
					unpack_step = STEP_DATA_CRC16;
				}
				index++;
			}break;
			
			case STEP_DATA_CRC16:
			{
				if (index < (REF_HEADER_CRC_CMDID_LEN + referee_receive_header.data_length))
				{
					protocol_packet[index] = referee_buff[index];
					index++;				
				}
				else
				{
					unpack_step = STEP_HEADER_SOF;
					index = 0;
					
					if (verify_CRC16_check_sum(protocol_packet, REF_HEADER_CRC_CMDID_LEN + referee_receive_header.data_length))
					{
						referee_data_solve(protocol_packet);
					}
				}
			}break;
			default:
      {
       unpack_step = STEP_HEADER_SOF;
       index = 0;
      }break;
		
		}
			
	}
		
}
/**
  * @brief          ���ƹ��ʣ���Ҫ���Ƶ������
  * @param[in]      chassis_power_control: ��������
  * @retval         total_current_limit
  */
fp32 chassis_power_control(void)
{
	fp32 chassis_power = 0.0f;
	fp32 chassis_power_buffer = 0.0f;
	fp32 total_current_limit = 0.0f;
	
	get_chassis_power_and_buffer(&chassis_power, &chassis_power_buffer);
	
	if(chassis_power > WARNING_POWER)
	{
		fp32 power_scale;
		if(chassis_power < POWER_LIMIT)
		{
			power_scale = (POWER_LIMIT - chassis_power) / (POWER_LIMIT - WARNING_POWER);
		}
		else
		{
			power_scale = 0.0f;			
		}
		total_current_limit = POWER_TOTAL_CURRENT_LIMIT * power_scale;
	}
	else
	{
		total_current_limit = POWER_TOTAL_CURRENT_LIMIT;
	}
	return total_current_limit;
	
}	


